import { useState } from "react";
import axios from "axios";
import { addDoc, collection, serverTimestamp } from "firebase/firestore";
import { auth, db } from "../firebase";

const API_URL = "http://localhost:5000/api/analyze";

const styles = {
  page: { maxWidth: 900, margin: "0 auto", padding: "32px 20px 60px", fontFamily: "Arial, sans-serif", color: "#17251d" },
  card: { background: "#fff", border: "1px solid #e1e9e2", borderRadius: 16, padding: 24, marginTop: 20 },
  label: { display: "block", fontWeight: 700, marginBottom: 8 },
  input: { width: "100%", boxSizing: "border-box", padding: 13, border: "1px solid #d4dfd6", borderRadius: 9, fontSize: 15, outlineColor: "#16804f" },
  button: { background: "#147d4e", color: "#fff", border: 0, padding: "13px 20px", borderRadius: 9, fontSize: 15, fontWeight: 700, cursor: "pointer" },
  section: { background: "#fff", border: "1px solid #e5ebe6", borderRadius: 12, padding: 20, marginTop: 16 },
};

function DataList({ items, emptyMessage }) {
  if (!Array.isArray(items) || items.length === 0) return <p style={{ color: "#647168" }}>{emptyMessage}</p>;
  return <ul style={{ lineHeight: 1.8, paddingLeft: 22 }}>{items.map((item, index) => (
    <li key={index}>
      {typeof item === "string" ? item : (
        <div>
          <strong>{item.retailer || item.source || item.title || "Result"}</strong>
          {item.price ? <> — <strong>{item.price}</strong></> : null}
          {item.title && item.retailer ? <div>{item.title}</div> : null}
          {item.note ? <div style={{ color: "#647168" }}>{item.note}</div> : null}
          {item.url ? <div><a href={item.url} target="_blank" rel="noreferrer">View listing</a></div> : null}
        </div>
      )}
    </li>
  ))}</ul>;
}

export default function ReelAnalyzer() {
  const [reelUrl, setReelUrl] = useState("");
  const [description, setDescription] = useState("");
  const [result, setResult] = useState(null);
  const [sourceData, setSourceData] = useState(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  async function analyzeReel(event) {
    event.preventDefault();
    const cleanUrl = reelUrl.trim();
    const cleanDescription = description.trim();
    setError(""); setNotice(""); setResult(null); setSourceData(null);

    const instagramPattern = /^https:\/\/(www\.)?instagram\.com\/(reel|reels|p)\/[A-Za-z0-9_-]+\/?(?:\?.*)?$/i;
    if (!instagramPattern.test(cleanUrl)) {
      setError("Please enter a valid Instagram Reel or post URL.");
      return;
    }
    if (cleanDescription.length > 2000) {
      setError("Product details must be 2000 characters or fewer.");
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post(API_URL, {
        reelUrl: cleanUrl,
        productDescription: cleanDescription,
      }, { timeout: 240000 });

      if (!response.data?.success || !response.data?.analysis) {
        throw new Error(response.data?.message || "No analysis was returned.");
      }

      const analysis = response.data.analysis;
      setResult(analysis);
      setSourceData(response.data.sourceData || null);

      if (auth.currentUser) {
        setSaving(true);
        try {
          await addDoc(collection(db, "users", auth.currentUser.uid, "analyses"), {
            reelUrl: cleanUrl,
            productDescription: cleanDescription,
            analysis,
            sourceData: response.data.sourceData || null,
            analyzedAt: response.data.analyzedAt || null,
            dataSource: response.data.dataSource || null,
            createdAt: serverTimestamp(),
          });
          setNotice("Analysis completed and saved to your history.");
        } catch (saveError) {
          console.error("Firebase history save failed:", saveError);
          setNotice("Analysis completed, but history could not be saved. Check Firestore permissions and your connection.");
        } finally {
          setSaving(false);
        }
      } else {
        setNotice("Analysis completed. Sign in to save your analysis history.");
      }
    } catch (requestError) {
      console.error("Reel analysis failed:", requestError);
      const status = requestError.response?.status;
      const serverMessage = requestError.response?.data?.message;
      if (status === 402) setError(serverMessage || "The data provider requires available credits.");
      else if (status === 422) setError(serverMessage || "The Reel was found, but there was not enough accessible data.");
      else if (status === 429 || status === 503) setError(serverMessage || "A service is temporarily busy or its quota is exhausted. Please try again later.");
      else if (status === 504 || requestError.code === "ECONNABORTED") setError("The request took too long. Please try again with another public Reel.");
      else if (!requestError.response) setError("Cannot connect to the backend. Check that the server is running on port 5000.");
      else setError(serverMessage || "Analysis failed. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  function clearForm() {
    setReelUrl(""); setDescription(""); setResult(null); setSourceData(null); setError(""); setNotice("");
  }

  return (
    <main style={styles.page}>
      <header>
        <p style={{ color: "#147d4e", fontWeight: 700, fontSize: 12, letterSpacing: 2 }}>SOCIALSIGHT · AI SHOPPING ASSISTANT</p>
        <h1 style={{ fontSize: 34, marginBottom: 8 }}>Instagram Reel Analyzer</h1>
        <p style={{ color: "#647168", lineHeight: 1.7 }}>Paste a public Instagram Reel link to fetch available data and generate a preliminary product assessment.</p>
      </header>

      <form onSubmit={analyzeReel} style={styles.card}>
        <label htmlFor="reelUrl" style={styles.label}>Instagram Reel URL</label>
        <input id="reelUrl" type="url" required value={reelUrl} onChange={(event) => setReelUrl(event.target.value)} placeholder="https://www.instagram.com/reel/..." style={styles.input} />
        <div style={{ marginTop: 22 }}>
          <label htmlFor="description" style={styles.label}>Additional product details (optional)</label>
          <textarea id="description" value={description} maxLength={2000} onChange={(event) => setDescription(event.target.value)} placeholder="Add product details if you know them." rows={3} style={{ ...styles.input, resize: "vertical", lineHeight: 1.6 }} />
          <p style={{ textAlign: "right", color: "#78847b", fontSize: 12, marginTop: 5 }}>{description.length}/2000</p>
        </div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 12, marginTop: 18 }}>
          <button type="submit" disabled={loading} style={{ ...styles.button, opacity: loading ? 0.7 : 1 }}>{loading ? "Fetching and analyzing..." : "Analyze Reel"}</button>
          <button type="button" onClick={clearForm} disabled={loading} style={{ padding: "12px 18px", background: "#fff", border: "1px solid #d4dfd6", borderRadius: 9, cursor: "pointer" }}>Clear</button>
        </div>
        {loading && <p role="status" style={{ color: "#52675a", marginTop: 18 }}>Fetching Reel comments, checking retailer listings and analyzing. This may take a little while.</p>}
      </form>

      {error && <div role="alert" style={{ marginTop: 20, padding: 16, borderRadius: 10, background: "#fff0ef", border: "1px solid #ffd5d1", color: "#a12622", lineHeight: 1.6 }}><strong>Analysis failed</strong><p style={{ marginBottom: 0 }}>{error}</p></div>}
      {notice && <div role="status" style={{ marginTop: 18, padding: 14, borderRadius: 9, background: "#edf8f0", color: "#17663b", lineHeight: 1.6 }}>{notice}{saving ? " Saving..." : ""}</div>}

      {result && <section aria-live="polite" style={{ marginTop: 28, padding: 22, borderRadius: 16, background: "#f7faf7", border: "1px solid #e1e9e2" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
          <h2 style={{ margin: 0 }}>{result.productName || "Product Assessment"}</h2>
          <span style={{ padding: "8px 12px", background: "#e3f4e9", color: "#17663b", borderRadius: 30, fontSize: 13, fontWeight: 700 }}>Confidence: {result.confidence ?? 0}%</span>
        </div>
        <p style={{ color: "#52675a" }}><strong>Category:</strong> {result.category || "Not identified"}</p>
        <div style={styles.section}><h3 style={{ marginTop: 0 }}>Product Summary</h3><p style={{ lineHeight: 1.8 }}>{result.summary || "No summary available."}</p></div>
        <div style={styles.section}><h3 style={{ marginTop: 0 }}>Buying Recommendation</h3><p style={{ lineHeight: 1.8 }}>{result.recommendation || "Need more information"}</p></div>
        <div style={styles.section}><h3 style={{ marginTop: 0 }}>Reasons</h3><DataList items={result.reasons} emptyMessage="No supporting reasons were returned." /></div>
        <div style={styles.section}>
          <h3 style={{ marginTop: 0 }}>Comment Sentiment</h3>
          <p>{result.sentiment?.status || "No comments analyzed"}</p>
          <p style={{ color: "#52675a", lineHeight: 1.8 }}>Positive: {result.sentiment?.positive ?? "N/A"} | Neutral: {result.sentiment?.neutral ?? "N/A"} | Negative: {result.sentiment?.negative ?? "N/A"}</p>
        </div>
        <div style={styles.section}>
          <h3 style={{ marginTop: 0 }}>Review Trust</h3>
          <p><strong>Evidence score:</strong> {result.reviewTrust?.score == null ? "N/A" : `${result.reviewTrust.score}/100`}</p>
          <p>{result.reviewTrust?.status || "Not enough accessible comments to assess review evidence."}</p>
          {result.reviewTrust?.commentsAnalyzed != null && <p style={{ color: "#647168" }}>Comments used: {result.reviewTrust.commentsAnalyzed}</p>}
        </div>
        <div style={styles.section}>
          <h3 style={{ marginTop: 0 }}>Price Comparison</h3>
          <p style={{ color: "#647168" }}>Prices are search-result listings, not guaranteed checkout prices. Open the listing to confirm availability, seller and final price.</p>
          <DataList items={result.priceComparison} emptyMessage="No matching retailer prices found. Check that SERPAPI_API_KEY is configured in backend/.env." />
        </div>
        {sourceData && <div style={styles.section}>
          <h3 style={{ marginTop: 0 }}>Fetched Reel Data</h3>
          <p><strong>Creator:</strong> {sourceData.creator || "Unavailable"}</p>
          <p><strong>Likes:</strong> {sourceData.likesCount ?? "Unavailable"}</p>
          <p><strong>Comments reported:</strong> {sourceData.commentsCount ?? "Unavailable"}</p>
          <p><strong>Comments analyzed:</strong> {sourceData.commentsAnalyzed ?? 0}</p>
          {sourceData.caption && <><h4>Caption</h4><p style={{ lineHeight: 1.7, whiteSpace: "pre-wrap" }}>{sourceData.caption}</p></>}
        </div>}
        <p style={{ marginTop: 22, color: "#78847b", fontSize: 12, lineHeight: 1.7 }}>AI-generated preliminary assessment. The evidence score is not proof that reviews are authentic or fake. Retailer prices may change; confirm on the seller's website.</p>
      </section>}
    </main>
  );
}
