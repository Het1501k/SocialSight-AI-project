
import { signOut } from "firebase/auth";
import { useNavigate } from "react-router-dom";
import { auth } from "../firebase";

export default function Dashboard() {
  const navigate = useNavigate();
  const user = auth.currentUser;

  async function handleLogout() {
    await signOut(auth);
    navigate("/login", { replace: true });
  }

  return (
    <main className="dashboard">
      <header>
        <h1>SocialSight</h1>
        <button onClick={handleLogout}>Logout</button>
      </header>

      <section>
        <h2>
          Welcome{user?.displayName ? `, ${user.displayName}` : ""}!
        </h2>
        <p>{user?.email}</p>
        <p>Your AI-powered shopping assistant is ready.</p>
      </section>

      <section className="dashboard-grid">
        <article>
          <h3>Reel Analyzer</h3>
          <p>Analyze products discovered on Instagram Reels.</p>
        </article>
        <article>
          <h3>Analysis History</h3>
          <p>Your saved product analyses will appear here.</p>
        </article>
        <article>
          <h3>Wishlist</h3>
          <p>Keep track of products you like.</p>
        </article>
      </section>
    </main>
  );
}
